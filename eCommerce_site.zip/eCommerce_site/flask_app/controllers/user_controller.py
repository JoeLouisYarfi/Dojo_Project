from flask import render_template, redirect, request, session, flash
from flask_app.models.user_model import User
from flask_app import app
from flask_bcrypt import Bcrypt        
bcrypt = Bcrypt(app) 

# Renders the registration page
@app.route('/')
def home_page():
    return render_template("register.html")

#Post method for accepting data into registration form
@app.route('/register', methods = ["POST"])
def create_user():

    if not User.validate_user(request.form):
        return redirect('/')
    if User.get_user_by_email(request.form):
        flash ("Email or password is already used. Enter unique email or password")
    data = {
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email'],
        "password": bcrypt.generate_password_hash(request.form['password']),
        "confirm_pwd": request.form['confirm_pwd'],
    }
    # print(data['password'])
    
    user_id = User.save(data)
    session['user_id'] = user_id
    return redirect ('/registered') 

#Renders registration page after setting up account
@app.route('/registered')
def show_user():
    return render_template('setup.html')

#Renders the Login page
@app.route('/login')
def login_page():
    return render_template ("login.html")

#Post method for logging in 
@app.route('/login', methods = ['POST'])
def login():
    data = {'email': request.form['email']}
    user = User.get_user_by_email(data)

    if not user:
        flash ("Invalid email or password")
        return redirect('/login')
    if not bcrypt.check_password_hash(user.password, request.form ['password']):
        flash ("Invalid email or password")
        return redirect ('/login') 
    
    session['user_id'] = user.id
    return redirect ('/welcome') 

#Renders welcome page after loggin in
@app.route('/welcome')
def welcome():
    return render_template('welcome.html')


#Route for logging out
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

#Deletes an entry of details on a tv show
@app.route('/delete/<int:id>')
def delete_show(id):
    User.delete(id)
    return redirect ('/welcome')